#!/bin/bash

SOLR_PATH=/var/www/solr/example

start() {
	java -jar $SOLR_PATH/start.jar& 
}

